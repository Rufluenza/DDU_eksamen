import pygame as pg
from VideoPlayer import VideoPlayer

class GameVideoManager:
    """
    Manages video playback for different game states.
    This class acts as a wrapper around VideoPlayer to make it easier to use
    videos in different states of the game.
    """
    def __init__(self, game_clock):
        """
        Initialize the video manager.
        
        Args:
            game_clock (pygame.time.Clock): The main game clock for timing
        """
        self.game_clock = game_clock
        self.active_videos = {}  # Dictionary to store video players by state
        self.video_configs = {}  # Store configuration for each state's video
    
    def add_video_config(self, state_name, video_path, frame_size=(None, None), 
                        loop=False, auto_play=True, frame_stops=None, 
                        position=None, centered=True):
        """
        Add a video configuration for a specific game state.
        
        Args:
            state_name (str): Game state identifier (e.g., "intro", "ending")
            video_path (str): Path to the video file
            frame_size (tuple): Width and height for video scaling
            loop (bool): Whether the video should loop
            auto_play (bool): Whether the video should play automatically
            frame_stops (list): List of frame numbers where the video should stop
            position (tuple): Position to draw the video (x, y)
            centered (bool): Whether the position is the center or top-left
        """
        # Use sensible defaults if values aren't provided
        if position is None:
            # Default to center of screen if not specified
            screen_info = pg.display.Info()
            position = (screen_info.current_w // 2, screen_info.current_h // 2)
            
        if frame_size == (None, None):
            frame_size = None
        
        self.video_configs[state_name] = {
            'video_path': video_path,
            'frame_size': frame_size,
            'loop': loop,
            'auto_play': auto_play,
            'frame_stops': frame_stops or [],
            'position': position,
            'centered': centered,
            'callbacks': {}  # To store callbacks for frame stops
        }
    
    def register_frame_callback(self, state_name, frame_number, callback_func):
        """
        Register a callback function to be called when a specific frame is reached.
        
        Args:
            state_name (str): Game state identifier
            frame_number (int): Frame number to trigger the callback
            callback_func (function): Function to call when the frame is reached
        """
        if state_name not in self.video_configs:
            print(f"Warning: No video config found for state '{state_name}'")
            return
            
        if 'callbacks' not in self.video_configs[state_name]:
            self.video_configs[state_name]['callbacks'] = {}
            
        self.video_configs[state_name]['callbacks'][frame_number] = callback_func
    
    def load_video_for_state(self, state_name):
        """
        Load a video for a specific game state.
        
        Args:
            state_name (str): Game state identifier
        
        Returns:
            bool: True if video was loaded successfully, False otherwise
        """
        if state_name not in self.video_configs:
            print(f"No video configuration found for state: {state_name}")
            return False
        
        config = self.video_configs[state_name]
        
        # If we already have a player for this state, release it
        if state_name in self.active_videos and self.active_videos[state_name] is not None:
            self.active_videos[state_name].release()
        
        # Create a new player
        self.active_videos[state_name] = VideoPlayer(
            video_path=config['video_path'],
            game_clock=self.game_clock,
            loop=config['loop'],
            auto_play=config['auto_play'],
            frame_size=config['frame_size'],
            position=config['position'],
            centered=config['centered']
        )
        
        return self.active_videos[state_name].loaded
    
    def update(self, state_name):
        """
        Update the video player for the current state.
        
        Args:
            state_name (str): Current game state
        """
        if state_name not in self.active_videos or self.active_videos[state_name] is None:
            return
        
        video_player = self.active_videos[state_name]
        
        # Skip if video isn't loaded
        if not video_player.loaded:
            return
        
        # Store the current frame before updating
        prev_frame = video_player.get_current_frame_num
        
        # Update the video player
        video_player.update()
        
        # Check if we've hit any frame stops
        current_frame = video_player.get_current_frame_num
        
        # If we've hit a frame stop, pause the video
        frame_stops = self.video_configs[state_name]['frame_stops']
        for stop_frame in frame_stops:
            # Check if we've just crossed a stop frame boundary
            if prev_frame < stop_frame <= current_frame:
                video_player.pause()
                video_player.seek(stop_frame)  # Ensure we're exactly on the stop frame
                
                # Execute callback if one exists for this frame
                callbacks = self.video_configs[state_name].get('callbacks', {})
                if stop_frame in callbacks:
                    callbacks[stop_frame]()
                
                break
    
    def draw(self, state_name, surface):
        """
        Draw the video for the current state.
        
        Args:
            state_name (str): Current game state
            surface (pygame.Surface): Surface to draw the video on
        """
        if state_name in self.active_videos and self.active_videos[state_name] is not None:
            self.active_videos[state_name].draw(surface)
    
    def play(self, state_name):
        """Play the video for the specified state."""
        if state_name in self.active_videos and self.active_videos[state_name] is not None:
            self.active_videos[state_name].play()
    
    def pause(self, state_name):
        """Pause the video for the specified state."""
        if state_name in self.active_videos and self.active_videos[state_name] is not None:
            self.active_videos[state_name].pause()
    
    def seek(self, state_name, frame_number):
        """Seek to a specific frame in the video for the specified state."""
        if state_name in self.active_videos and self.active_videos[state_name] is not None:
            self.active_videos[state_name].seek(frame_number)
    
    def is_playing(self, state_name):
        """Check if the video for the specified state is playing."""
        if state_name in self.active_videos and self.active_videos[state_name] is not None:
            return self.active_videos[state_name].is_playing
        return False
    
    def get_current_frame(self, state_name):
        """Get the current frame number of the video for the specified state."""
        if state_name in self.active_videos and self.active_videos[state_name] is not None:
            return self.active_videos[state_name].get_current_frame_num
        return 0
    
    def is_at_frame_stop(self, state_name):
        """
        Check if the current frame is at a frame stop.
        
        Args:
            state_name (str): Game state identifier
        
        Returns:
            bool: True if at a frame stop, False otherwise
        """
        if state_name not in self.active_videos or self.active_videos[state_name] is None:
            return False
            
        if state_name not in self.video_configs:
            return False
            
        current_frame = self.get_current_frame(state_name)
        frame_stops = self.video_configs[state_name]['frame_stops']
        
        return current_frame in frame_stops
    
    def cleanup(self):
        """Release all video players."""
        for state_name, video_player in self.active_videos.items():
            if video_player is not None:
                video_player.release()
        self.active_videos = {}