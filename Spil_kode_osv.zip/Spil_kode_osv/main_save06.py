import pygame as pg
import sys
import math
import time
from collections import deque
import random
import cv2
import numpy as np
from VideoPlayer import VideoPlayer
from GameVideoManager import GameVideoManager


# Initialize Pygame
pg.init()

# Screen settings
WIDTH, HEIGHT = 1680, 1050 #1920, 1080 #800, 800
SCREEN = pg.display.set_mode((WIDTH, HEIGHT))
pg.display.set_caption("Breaking Bad Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (2, 39, 23) # 022717

# Clock
CLOCK = pg.time.Clock()
FPS = 60

# Game States
STATE_INTRO = "intro"
STATE_MEASUREMENT = "measurement"
STATE_MIX = "mix"
STATE_TEMPERATURE = "temperature"
STATE_BREAK_AND_COLLECT = "break_and_collect"

# Starting state

current_state_num = 0
start_current_state_num = current_state_num
all_states = [STATE_INTRO, STATE_MEASUREMENT, STATE_MIX, STATE_TEMPERATURE, STATE_BREAK_AND_COLLECT]
current_state = all_states[current_state_num]

debug_state = False

# Video settings
VIDEO_PATH = "assets/Video6.mp4"  # Video6 virker Video8 virker ikke
cap = None
video_playing = True
current_frame_number = 0
total_frames = 0
video_loaded = False

# Constants
ROTATIONAL_AXIS_ID = [0, 1]     # Axis 0 = X, Axis 1 = Y
DEADZONE = 0.2
TIME_WINDOW = 5.0               # Track rotation in the last 5 seconds

# Globals
angle_history = deque()         # Stores (timestamp, angle)
rotation_count = 0
_rpm_current_value = 0
last_angle = None

blue_number_images = []
red_number_images = []
for i in range(16):
    blue_number_images.append(pg.image.load(f"assets/Blue{i}.png"))
    if i <= 10:
        red_number_images.append(pg.image.load(f"assets/Red{i}.png"))


# Initialize Joystick
pg.joystick.init()
joysticks = [pg.joystick.Joystick(i) for i in range(pg.joystick.get_count())]
game_joystick = None
joystick_available = False

if joysticks:
    game_joystick = joysticks[0]  # Use the first joystick found
    game_joystick.init()
    joystick_available = True
    print(f"Joystick '{game_joystick.get_name()}' initialized.")
    print(f"Number of axes: {game_joystick.get_numaxes()}")
    # You'll need to identify the correct axis for rotation on your Speedlink joystick.
    # Common axes for twist/rudder are 2, 3, or 4.
    # Check the console output when you run the game and move the rotational part of your joystick.
    print("Please test your joystick's axes to find the one for rotation.")
    print("The 'Axis X Value' will be shown in the MIXING phase.")
else:
    joystick_available = False
    print("No joystick detected.")



ROTATIONAL_AXIS_ID = [0, 1] # axis 0 = X, axis 1 = Y
_rpm_current_value = 0.0
MAX_RPM_FROM_JOYSTICK = 300 # Adjust this: max RPM when joystick axis is at full deflection


def draw_text(text, size, color, x, y):
    font = pg.font.SysFont("arial", size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(x, y))
    SCREEN.blit(text_surface, text_rect)

class Player:
    def __init__(self, name, key):
        self.name = name
        self.key = key
        self.score = 0.0 # action score for the game (ie. each press of the key)
        self.ready = False # ready to start the game
    
    def get_score(self):
        return self.score

    def update_score(self):
        self.score += 1.0
    
    def set_score(self, score):
        self.score = score
    
    def add_score(self, score):
        self.score += score
# Initialize players
player1 = Player("Player 1", pg.K_d)
player2 = Player("Player 2", pg.K_k)
can_update_state = False
timer = pg.time.get_ticks()
last_timer = 0
timer_offset = pg.time.get_ticks()
intro_num = 0
intro_allow_next = False
video = None
intro_frame_stop = [217] # [90, 120, 165, 202]

video_first_draw = True
video_set_frame = True


    

def reset_game():
    global current_state_num, current_state, can_update_state, timer_offset, start_current_state_num
    current_state_num = start_current_state_num
    current_state = all_states[current_state_num]
    can_update_state = False
    player1.set_score(0.0)
    player2.set_score(0.0)
    timer_offset = pg.time.get_ticks()
    print(f"Game reset to state: {current_state}")



def video_init():
    global video
    if video is None:
        video = VideoPlayer(
            video_path=VIDEO_PATH,
            game_clock=CLOCK, # Pass your main game clock
            loop=False,
            auto_play=True,
            frame_size=(WIDTH, HEIGHT),
            position=(WIDTH // 2, HEIGHT // 2), # Centered
            centered=True
        )
        if not video.loaded:
            print(f"Video player failed to load: {video.error_message}")
            # No need to draw error here, player.draw() will handle it.
            
            
def draw_video(start_frame=1, end_frame=1, video_set_frame=False):
    global video, video_first_draw
    if video:
        if video.loaded:
            if video_first_draw == False: # Only for the intro # FIXME
                video.seek(start_frame)
                video_first_draw = True
            if video_set_frame:
                video.seek(start_frame)
                video_set_frame = False
            if video.get_current_frame_num <= end_frame:#intro_frame_stop[min(intro_num, len(intro_frame_stop)-1)]:
                #print(f"Current frame: {video.get_current_frame_num}/{video.get_total_frames}")
                video.update()
        video.draw(SCREEN)
        if video.loaded:
            status_text = f"Frame: {video.get_current_frame_num}/{video.get_total_frames} | {'Playing' if video.is_playing else 'Paused'}"
            draw_text(status_text, 20, WHITE, WIDTH // 2, HEIGHT - 70)
            draw_text("SPACE: Play/Pause | J: Seek fr.100 | ENTER: Progress", 20, WHITE, WIDTH // 2, HEIGHT - 40)
    


# State functions
def intro(event):
    global can_update_state, intro_allow_next, intro_num, timer_offset, current_state_num, intro_frame_stop
    global cap, video_playing, current_frame_number, total_frames, video_loaded, video, video_first_draw # Video globals
    
    # --- NEW VIDEO PLAYER ---
    # Initialize video player
    video_init()
    # Draw video
    
    draw_video(intro_frame_stop[intro_num], intro_frame_stop[min(intro_num+1, len(intro_frame_stop)-1)])
    """
    if video is None:
        video = VideoPlayer(
            video_path=VIDEO_PATH,
            game_clock=CLOCK, # Pass your main game clock
            loop=False,
            auto_play=True,
            frame_size=(WIDTH, HEIGHT),
            position=(WIDTH // 2, HEIGHT // 2), # Centered
            centered=True
        )
        if not video.loaded:
            print(f"Video player failed to load: {video.error_message}")
            # No need to draw error here, player.draw() will handle it.
        
    if video:
        if video.loaded:
            
            if video.get_current_frame_num <= intro_frame_stop[min(intro_num, len(intro_frame_stop)-1)]:
                print(f"Current frame: {video.get_current_frame_num}/{video.get_total_frames}")
                video.update()
        video.draw(SCREEN)
        if video.loaded:
            status_text = f"Frame: {video.get_current_frame_num}/{video.get_total_frames} | {'Playing' if video.is_playing else 'Paused'}"
            draw_text(status_text, 20, WHITE, WIDTH // 2, HEIGHT - 70)
            draw_text("SPACE: Play/Pause | J: Seek fr.100 | ENTER: Progress", 20, WHITE, WIDTH // 2, HEIGHT - 40)
    """
    
    if event.type == pg.KEYDOWN:
        if event.key == pg.K_j:
            #video.seek(100)
            print("Jumped to frame 100")
        if event.key == pg.K_SPACE:
            # Pause video
            if video.playing:
                video.pause()
            else:
                video.play()
            print(f"Video {'paused' if not video else 'playing'}")
        if event.key == pg.K_RETURN:
            print(f"Intro num: {intro_num}")
            if video.get_current_frame_num >= intro_frame_stop[min(intro_num, len(intro_frame_stop)-1)]:
                if intro_num >= len(intro_frame_stop)-1:
                    can_update_state = True
                    update_state()
                    #current_state_num = (current_state_num + 1) % len(all_states)
                else:
                    intro_num += 1
                    
                    #video_playing = True
                    #intro_allow_next = False
                    # reset timer
                    #timer_offset = pg.time.get_ticks()
        
        
                
        
    # --- END NEW VIDEO PLAYER ---

    

def calculate_angle(p1, p2):
    if p1 == 0 and p2 == 0:
        return 0  # neutral
    elif p2 == 0:
        return -math.pi / 6  # full left tilt
    elif p1 == 0:
        return math.pi / 6   # full right tilt

    actual_ratio = p1 / p2
    ideal_ratio = 2 / 3
    max_diff = 2  # Define a max tolerable deviation (e.g., actual_ratio in [0, 2.67])

    # Compute normalized deviation from ideal
    diff = actual_ratio - ideal_ratio
    normalized = diff / max_diff  # e.g., (1.5 - 0.66) / 2 = ~0.42
    normalized = max(-1, min(1, normalized))  # Clamp to [-1, 1]

    angle_rad = normalized * (math.pi / 6)  # Max ±30°
    return angle_rad

measurement_frame_stop = [250, 300]
measurement_setup = True

# Angle frames are -30 degrees to 30 degrees
# so -30, -15, 0, 15, 30
# and there are 2 frames for each angle with the negative angles having (left side full, right side empty) and (left side full, right side full)
# and the positive angles having (left side empty, right side full) and (left side full, right side full)
# index 0 is left side and index 1 is right side
# i.e angle_frames[0][0] is -30 degrees left side full and right side empty
# i.e angle_frames[0][1] is -30 degrees left side full and right side full
# i.e angle_frames[1][0] is -15 degrees left side full and right side empty
# i.e angle_frames[1][1] is -15 degrees left side full and right side full
# i.e angle_frames[2][0] is 0 degrees left side empty and right side empty
# i.e angle_frames[2][1] is 0 degrees left side full and right side full
# i.e angle_frames[3][0] is 15 degrees left side empty and right side full
# i.e angle_frames[3][1] is 15 degrees left side full and right side full
# i.e angle_frames[4][0] is 30 degrees left side empty and right side full
# i.e angle_frames[4][1] is 30 degrees left side full and right side full
angle_frames = [[272, 273], [274, 275], [243, 244], [276, 277], [278, 279]]
#angle_frames = [[272, 273], [274, 275], [244, 245], [276, 277], [278, 279]]
# Possible angles are
# p1: 0, p2: 0 = 0 degrees
# p1: 1, p2: 0 = -15 degrees
# p1: 2, p2: 0 = -30 degrees
# p1: 0, p2: 1 = 15 degrees
# p1: 0, p2: 2 = 30 degrees
# p1: 2, p2: 3 = 0 degrees
measurement_frame_outro = [246, 269]
measurement_outro_start = False
measurement_outro_started = False
measurement_pause_frames = True
measurement_play_intro = True

def measurement(event):
    global can_update_state, measurement_setup, measurement_frame_stop, video_set_frame
    global measurement_outro_start, measurement_outro_started, measurement_pause_frames, measurement_play_intro
    SCREEN.fill((30, 30, 30))
    
    # Draw video
    video_init() # if video is None
    if measurement_setup:
        draw_video(intro_frame_stop[-1], measurement_frame_stop[0], video_set_frame=measurement_play_intro) # Draw the first frame of the video
        measurement_play_intro = False
        if video.get_current_frame_num >= measurement_frame_stop[0]:
            # Draw the second frame of the video
            draw_video(measurement_frame_stop[0], measurement_frame_stop[1], video_set_frame=measurement_setup)
            measurement_setup = False
    # Get player scores
    p1 = player1.get_score()
    p2 = player2.get_score()

    # Calculate ratio and angle
    if p2 == 0 and p1 == 0:
        angle_ratio = 0
    elif p2 == 0:
        if p1 == 1:
            angle_ratio = 0.5 # half tilt left
        else:
            angle_ratio = 1# full tilt left
        #angle_ratio = 1  
    else:
        ratio = p1 / p2
        ideal_ratio = 2 / 3
        diff = ratio - ideal_ratio

        # Normalize difference to range -1 to 1
        angle_ratio = max(-1.0, min(1.0, diff))

    # Convert to radians (max ±30 degrees → ±π/6 radians)
    #angle_rad = angle_ratio * (math.pi / 6)
    #angle_deg = math.degrees(angle_rad)
    
    angle_rad = calculate_angle(p1, p2)
    angle_deg = math.degrees(angle_rad)

    
    # New angle calculation
    # It is a bit off, but it is ok
    new_angle = math.atan2(p1, p2) # atan2(y, x)
    # if new_angle == round(0.588) == equal weight 2:3
    # if it is less than 0.588, it is a bit right
    # if it is more than 0.588, it is a bit left
    tolerance = 0.1
    target_angle = 0.588
    p1_max = 1.57
    
    
    #print(f"Angle: {angle_deg:.2f} degrees")

    # Scale line (like a seesaw)
    center = (WIDTH // 2, HEIGHT // 2)
    length = 200
    dx = math.cos(angle_rad) * length / 2
    dy = math.sin(angle_rad) * length / 2

    start = (center[0] - dx, center[1] + dy)
    end = (center[0] + dx, center[1] - dy)
   
    
    if measurement_setup == False and not measurement_outro_start:
        #print(f"Angle: {new_angle:.2f} degrees")
        if measurement_pause_frames:
            video.pause()
        # RIGHT SIDE FULL
        if new_angle == 0:
            if p1 == 0:
                if p2 == 1:
                    #print("RIGHT SIDE")
                    draw_video(angle_frames[3][0], angle_frames[3][0], video_set_frame=True)
                elif p2 > 1:
                    #print("RIGHT SIDE FULL")
                    draw_video(angle_frames[4][0], angle_frames[4][0], video_set_frame=True)
        if p1 == 0 and p2 == 0:
            #print("Both sides empty")
            draw_video(angle_frames[2][0], angle_frames[2][0], video_set_frame=True)
        # Draw the angle frames
        if p2 == 0:
            if p1 == 1:
                #print("LEFT SIDE")
                draw_video(angle_frames[1][0], angle_frames[1][0], video_set_frame=True)
            elif p1 > 1:
                #print("LEFT SIDE FULL")
                draw_video(angle_frames[0][0], angle_frames[0][0], video_set_frame=True)
        
        # POSITIVE ANGLES
        """
        if p1 == 0:
            if p2 == 1:
                draw_video(angle_frames[2][0], angle_frames[2][0], video_set_frame=True)
            elif p2 > 1:
                draw_video(angle_frames[3][0], angle_frames[3][0], video_set_frame=True)
        """
        
        if p1 > 0 and p2 > 0:
            # Draw the angle frames
            # Depending on the angle_rad
            # if angle_rad < 0:
            # IF IT IS CORRECT AND FULL ON BOTH SIDES
            if new_angle == target_angle or abs(new_angle - target_angle) < tolerance:
                # Draw the angle frames
                #draw_video(angle_frames[2][1], angle_frames[2][1], video_set_frame=True)
                # SHOW THE VIDEO FOR CORRECT ANGLE
                video.play()
                if measurement_outro_started == False:
                    measurement_outro_started = True
                    measurement_outro_start = True
                    measurement_pause_frames = False
                    
                    
                    video.play()
                    #video.seek(measurement_frame_outro[0])
                    #video.play()
                
                
            # much higher p1 than p2
            elif new_angle > target_angle:
                # left side
                if new_angle < p1_max and new_angle >= target_angle*2: # full left
                    draw_video(angle_frames[0][1], angle_frames[0][1], video_set_frame=True)
                else: # bit left
                    draw_video(angle_frames[1][1], angle_frames[1][1], video_set_frame=True)
            
            elif new_angle < target_angle:
                # right side
                if new_angle < target_angle/2: # full right
                    draw_video(angle_frames[3][1], angle_frames[3][1], video_set_frame=True)
                else: # bit right
                    draw_video(angle_frames[4][1], angle_frames[4][1], video_set_frame=True)
            """
            elif new_angle < p1_max and new_angle >= target_angle*2: # full left and still right side full
                draw_video(angle_frames[0][1], angle_frames[0][1], video_set_frame=True)
            
            elif new_angle > target_angle*2 and new_angle < target_angle + tolerance: # bit left and still right side full
                draw_video(angle_frames[1][1], angle_frames[1][1], video_set_frame=True)
            
            elif new_angle > 0 and new_angle < target_angle/2: # full right
                draw_video(angle_frames[3][1], angle_frames[3][1], video_set_frame=True)
            
            elif new_angle > target_angle/2 and new_angle < target_angle + tolerance: # bit right
                draw_video(angle_frames[4][1], angle_frames[4][1], video_set_frame=True)
            # if it is a bit off, but not full
            # STRAIGHT ANGLE
            """
            
        
            """
            if round(p1 / p2, 2) == round(2 / 3, 2):
                draw_video(angle_frames[2][1], angle_frames[2][1], video_set_frame=True)
                # SHOW THE VIDEO FOR CORRECT ANGLE
            
            
            
            # NEGATIVE ANGLES
            # p1 Much higher
            elif angle_deg < -20: # full left and still right side full
                draw_video(angle_frames[0][1], angle_frames[0][1], video_set_frame=True)
                #draw_video(angle_frames[3][1], angle_frames[3][1], video_set_frame=True)
            # p1 a bit higher
            elif -20 <= angle_deg < -5: # bit left and still right side full
                draw_video(angle_frames[1][1], angle_frames[1][1], video_set_frame=True)
            # POSITIVE ANGLES
            # p2 a bit higher
            elif 5 < angle_deg <= 20: # full right and still left side full
                draw_video(angle_frames[4][1], angle_frames[4][1], video_set_frame=True)
            # p2 a much higher
            elif angle_deg > 20: # bit right and still left side full
                draw_video(angle_frames[3][1], angle_frames[3][1], video_set_frame=True)
            
            else:
                # SHOW ERROR
                draw_text("ERROR", 30, WHITE, WIDTH // 2, HEIGHT // 2)
            """
        # NEGATIVE ANGLES
        # AND NOT LEFT SIDE FULL
       
        #draw_text(f"ANGLE: {new_angle}", 30, WHITE, WIDTH // 2, HEIGHT // 2)
        #draw_text(f"P1: {p1} | P2: {p2}", 30, WHITE, WIDTH // 2, HEIGHT // 2 + 40)
         # show image of the score
        SCREEN.blit(red_number_images[int(p1)], (WIDTH // 4 - 50, HEIGHT // 2 - 400))
        SCREEN.blit(blue_number_images[int(p2)], (WIDTH - WIDTH // 4 - 50, HEIGHT // 2 - 400))

        #pass
    # Optional: Show ratio and angle
    #ratio_display = round(p1 / p2, 2) if p2 != 0 else "∞"
    #draw_text(f"P1: {p1} | P2: {p2} | Ratio: {ratio_display}", 20, WHITE, WIDTH // 2, HEIGHT - 40)
    if p2 != 0 and p1 != 0:
        if round(p1 / p2, 2) == round(2 / 3, 2): # add a tolerance of 0.1
            #draw_text(f"Ratio: {round(p1 / p2, 2)}", 20, WHITE, WIDTH // 2, HEIGHT // 2)
            #draw_text("Press Enter to proceed", 20, WHITE, WIDTH // 2, HEIGHT // 2 + 40)
            can_update_state = True
    
    if measurement_outro_start:
        # Draw the outro video
        print("OUTRO")
        draw_video(measurement_frame_outro[0], measurement_frame_outro[1], video_set_frame=measurement_outro_started)
        measurement_outro_started = False
        if video.get_current_frame_num >= measurement_frame_outro[1]:
            # Reset the outro state
            measurement_outro_start = False
            measurement_outro_started = False
            #video.play()
            can_update_state = True
            update_state()
    

def get_angle(x, y):
    """Returns angle in degrees from joystick x, y input."""
    return math.degrees(math.atan2(-y, x)) % 360  # atan2 uses -y to make up = 0°

rpm_target_timer_offset = 0
mix_frame_stop = [246, 269]
mix_frame_intro = [281, 332] # index 0 is 
mix_play_intro = True

mix_frame_still = 332
mix_frame_stir = [333, 342] # all frames in between
mix_frame_stir_loop = True
mix_setup = True
mix_pause_frames = False
mix_done_time = 5000 # 5 seconds
#mix_frame_arrow = 343
mix_frame_outro = [347, 368]
mix_outro_start = False
mix_outro_started = False

def mix(event):
    global _rpm_current_value, last_angle, rotation_count, rpm_target_timer_offset, can_update_state
    global mix_setup, mix_frame_stop, mix_frame_intro, mix_play_intro, mix_frame_still, mix_frame_stir, mix_frame_stir_loop, mix_pause_frames, mix_done_time
    global mix_frame_outro, mix_outro_start, mix_outro_started
    SCREEN.fill((50, 50, 80))
    #draw_text("Mixing Phase", 30, WHITE, WIDTH // 2, HEIGHT // 8)
    if mix_play_intro:
        draw_video(mix_frame_intro[0], mix_frame_intro[1], video_set_frame=mix_setup)
        mix_setup = False
        if video.get_current_frame_num >= mix_frame_intro[1]:
            mix_play_intro = False
            #mix_setup = True
            video.play()
    elif joystick_available and game_joystick and not mix_outro_start:
        x = game_joystick.get_axis(ROTATIONAL_AXIS_ID[0])
        y = game_joystick.get_axis(ROTATIONAL_AXIS_ID[1])

        # Deadzone
        if abs(x) < DEADZONE:
            x = 0.0
        if abs(y) < DEADZONE:
            y = 0.0

        # Draw axis info
        #draw_text(f"Axis ({ROTATIONAL_AXIS_ID[0]}, {ROTATIONAL_AXIS_ID[1]}): ({x:.2f}, {y:.2f})", 20, WHITE, WIDTH // 2, HEIGHT // 2 + 60)

        if x != 0.0 or y != 0.0: # moving
            current_time = time.time()
            current_angle = get_angle(x, y)

            if last_angle is not None:
                delta = (current_angle - last_angle + 540) % 360 - 180  # Normalize to [-180, 180]
                
                # Track rotation
                angle_history.append((current_time, current_angle))

            last_angle = current_angle
            draw_video(mix_frame_stir[0], mix_frame_stir[1], video_set_frame=mix_frame_stir_loop)
            if video.get_current_frame_num >= mix_frame_stir[1]:
                # set loop to True
                mix_frame_stir_loop = True
            else:
                mix_frame_stir_loop = False
            if mix_pause_frames:
                
                video.play()
                mix_pause_frames = False
            
                
        else: # not moving
            # Draw still frame
            mix_pause_frames = True
            draw_video(mix_frame_still, mix_frame_still, video_set_frame=mix_pause_frames)
            pass

        # Clean up history older than TIME_WINDOW
        now = time.time()
        while angle_history and now - angle_history[0][0] > TIME_WINDOW:
            angle_history.popleft()

        # Count full rotations
        total_angle_change = 0.0
        prev_angle = None
        for t, a in angle_history:
            if prev_angle is not None:
                delta = (a - prev_angle + 540) % 360 - 180
                total_angle_change += delta
            prev_angle = a

        # Compute number of full rotations
        rotations = abs(total_angle_change / 360.0)
        _rpm_current_value = (rotations / TIME_WINDOW) * 60.0

        #draw_text(f"RPM: {int(_rpm_current_value)}", 30, WHITE, WIDTH // 4, HEIGHT // 2)
        rpm_target = 45
        
        rpm_target_tolerance = 30
        rpm_target_max_tolerance = rpm_target + rpm_target_tolerance
        rpm_max = 100
        rpm_arrow_width = 200
        rpm_arrow_height = 10
        rpm_arrow_xpos = WIDTH // 4 + WIDTH // 2 + 100
        # 66 is the maximum value of the arrow
        # clamp the value to 0-66
        if _rpm_current_value/rpm_max > 1:
            _rpm_current_value = rpm_max
        rpm_arrow_ypos = HEIGHT * 0.70 - (_rpm_current_value/rpm_max) * 250
        pg.draw.line(SCREEN, BLACK, (rpm_arrow_xpos, rpm_arrow_ypos), (rpm_arrow_xpos + rpm_arrow_width, rpm_arrow_ypos), rpm_arrow_height)

        if _rpm_current_value < rpm_target or _rpm_current_value > rpm_target_max_tolerance:
            # EITHER TOO LOW OR TOO HIGH
            # Reset the timer if we drop below target
            rpm_target_timer_offset = None
        else:
            if rpm_target_timer_offset is None:
                rpm_target_timer_offset = pg.time.get_ticks()  # Start the countdown

            if pg.time.get_ticks() - rpm_target_timer_offset > mix_done_time:
                #can_update_state = True
                #draw_text("Mixing complete! Press Enter.", 20, WHITE, WIDTH // 2, HEIGHT - 50)
                print("Mixing complete! Press Enter to proceed.")
                mix_outro_started = True
                mix_outro_start = True
                video.play()
    elif mix_outro_start:
        print("OUTRO")
        draw_video(mix_frame_outro[0], mix_frame_outro[1], video_set_frame=mix_outro_started)
        mix_outro_started = False
        if video.get_current_frame_num >= mix_frame_outro[1]:
            # Reset the outro state
            mix_outro_start = False
            mix_outro_started = False
            #video.play()
            can_update_state = True
            update_state()
            
    

    if not joystick_available and not game_joystick:
        draw_text("Joystick not detected!", 20, WHITE, WIDTH // 2, HEIGHT // 2 + 60)
        draw_text("RPM: N/A", 30, WHITE, WIDTH // 4, HEIGHT // 2)
        # can_update_state = True # Or False, depending on desired behavior without joystick
    
    # Draw circle on left side of screen
def draw_pie_slice(surface, center, radius, start_deg, end_deg, color, points=20):
    start_rad = math.radians(start_deg)
    end_rad = math.radians(end_deg)

    angle_step = (end_rad - start_rad) / points
    point_list = [center]

    for i in range(points + 1):
        angle = start_rad + i * angle_step
        x = center[0] + math.cos(angle) * radius
        y = center[1] + math.sin(angle) * radius
        point_list.append((x, y))

    pg.draw.polygon(surface, color, point_list)
    
temperature_play_intro = True
temperature_frame_intro = [370, 382]
temperature_frame_outro = [382, 392]
temperature_outro_start = False
temperature_outro_started = False
temperature_setup = True
temperature_timer_offset = None
temperature_correct_time = 5000 # 5 seconds
def temperature(event):
    global can_update_state, temperature_play_intro, temperature_frame_intro, temperature_frame_outro  # timer_offset is a global, read but not modified here.
    global temperature_setup, temperature_outro_start, temperature_outro_started
    global temperature_timer_offset, temperature_correct_time
    SCREEN.fill((80, 30, 30))
    #draw_text("Temperature Control Phase", 30, WHITE, WIDTH // 2, HEIGHT // 8) # Adjusted y for consistency
    video_init()
    if temperature_play_intro:
        video.play()
        draw_video(temperature_frame_intro[0], temperature_frame_intro[1], video_set_frame=temperature_setup)
        temperature_setup = False
        if video.get_current_frame_num >= temperature_frame_intro[1]:
            temperature_play_intro = False
            #temperature_setup = True
            video.pause() # only one frame for the game
    elif not temperature_play_intro and not temperature_outro_start:
        # Draw the temperature control circle
        draw_video(temperature_frame_intro[1], temperature_frame_intro[1], video_set_frame=temperature_setup)
        
        
    
        
        center = (WIDTH // 4-125, HEIGHT // 2- 36)  # Center of the circle
        radius = WIDTH // 8
        temp_range_degrees = 95  # The visual extent of the green zone in degrees
        green_zone_start_angle = 195-(temp_range_degrees/2)  # Starting angle of the green zone
        green_zone_end_angle = green_zone_start_angle + temp_range_degrees

        # Draw the visual elements for temperature control
        #pg.draw.circle(SCREEN, WHITE, center, radius)
        # ------ DEBUGGING DRAW THE GREEN ZONE ------
        #draw_pie_slice(SCREEN, center, radius, green_zone_start_angle, green_zone_end_angle, GREEN)


        # Implement a steady temperature decay (player2.score decreases over time)
        COOLING_RATE_PER_FRAME = 0.15  # Adjust this value for game balance (how fast temperature drops)

        # 2. Address: "i need it to not subtract the score when the value is under 0"
        if player2.get_score() > 0:
            new_score = player2.get_score() - COOLING_RATE_PER_FRAME
            player2.set_score(max(0, new_score))  # Ensure score doesn't drop below 0

        # --- Needle and Win Condition Logic ---
        needle_length = 140
        current_needle_angle = player2.get_score() * 10 - 90

        # Draw the temperature needle
        pg.draw.line(SCREEN, BLACK,
                    (center[0], center[1]),  # Starting point of the needle (center of the circle)
                    (center[0] + math.cos(math.radians(current_needle_angle)) * needle_length,
                    center[1] + math.sin(math.radians(current_needle_angle)) * needle_length),
                    5)  # Thickness of the needle

        normalized_needle_angle = current_needle_angle % 360  # Normalize angle to 0-360 range
        """
        if _rpm_current_value < rpm_target or _rpm_current_value > rpm_target_max_tolerance:
                    # EITHER TOO LOW OR TOO HIGH
                    # Reset the timer if we drop below target
                    rpm_target_timer_offset = None
                else:
                    if rpm_target_timer_offset is None:
                        rpm_target_timer_offset = pg.time.get_ticks()  # Start the countdown

                    if pg.time.get_ticks() - rpm_target_timer_offset > mix_done_time:
        """
        if green_zone_start_angle <= normalized_needle_angle <= green_zone_end_angle:
            
            #can_update_state = True  # Player can proceed to the next state
            if temperature_timer_offset is None:
                temperature_timer_offset = pg.time.get_ticks()
            if pg.time.get_ticks() - temperature_timer_offset > temperature_correct_time:
                # Proceed to the next state
                temperature_outro_started = True
                temperature_outro_start = True
                video.play()
                #print("Temperature control complete! Press Enter to proceed.")
        else:
            temperature_timer_offset = pg.time.get_ticks()  # Start the countdown
            can_update_state = False
    if temperature_outro_start:
        print("OUTRO")
        draw_video(temperature_frame_outro[0], temperature_frame_outro[1], video_set_frame=temperature_outro_started)
        temperature_outro_started = False
        if video.get_current_frame_num >= temperature_frame_outro[1]:
            # Reset the outro state
            temperature_outro_start = False
            temperature_outro_started = False
            #video.play()
            can_update_state = True
            update_state()
        # Optional: For debugging, you can print score and angle
        # print(f"P2 Score: {player2.get_score():.2f}, Needle Angle: {current_needle_angle:.2f}, In Zone: {can_update_state}")
    
plate_step = 0
plate_step_max = 100
plate_timer_offset = None
plate_timer = 0
def draw_plate(step):
    # Draw the plate
    plate_size = (600, 400)
    plate_pos = (WIDTH // 4 - plate_size[0] // 2 + (step/100*WIDTH//2), HEIGHT // 2 - plate_size[1] // 2)
    pg.draw.rect(SCREEN, WHITE, plate_pos + plate_size)

    # Draw the step number
    draw_text(f"Step {step}", 30, BLACK, plate_pos[0] + plate_size[0] // 2, plate_pos[1] + plate_size[1] // 2)

button_list = [pg.K_q, pg.K_w, pg.K_q, pg.K_a]
button_list_text = ["Q", "W", "Q", "A"]
target_button = None
target_button_num = 0
break_and_collect_setup = True
break_and_collect_play_intro = True
break_and_collect_outro_start = False
break_and_collect_outro_started = False
break_and_collect_frame_intro = [392, 444]
button_frames = [445, 446, 447, 448]
break_and_collect_frame_outro = [449, 536]
break_and_collect_pause_frames = False
draw_debug_plate = False

def break_and_collect(event):
    global can_update_state, plate_step, plate_step_max, plate_timer_offset, plate_timer, target_button, button_list, button_list_text, target_button_num
    global break_and_collect_setup, break_and_collect_play_intro, break_and_collect_frame_intro, break_and_collect_frame_outro, break_and_collect_pause_frames
    global break_and_collect_outro_start, break_and_collect_outro_started
    #SCREEN.fill((20, 60, 20))
    
    video_init()
    if break_and_collect_play_intro:
        video.play()
        draw_video(break_and_collect_frame_intro[0], break_and_collect_frame_intro[1], video_set_frame=break_and_collect_setup)
        break_and_collect_setup = False
        if video.get_current_frame_num >= break_and_collect_frame_intro[1]:
            break_and_collect_play_intro = False
            #break_and_collect_setup = True
            
            video.pause()
    
        
    #draw_text("Break & Collect Product Phase", 30, WHITE, WIDTH // 2, HEIGHT // 2)
    # show the player 1 a rectangle with the score
    left_side = (WIDTH // 2 - 50, HEIGHT // 2 - 50)
    right_side = (WIDTH // 2 + 50, HEIGHT // 2 - 50)
    plate_size = (600, 400)
    plate_pos = (WIDTH // 4 - plate_size[0] // 2, HEIGHT // 2 - plate_size[1] // 2)
    
    # show player 2 a random button from button list
    if target_button is None:
        #target_button = random.choice(button_list)
        target_button = button_list[target_button_num]
    target_button_text = button_list_text[button_list.index(target_button)]
    if not break_and_collect_play_intro and not break_and_collect_outro_start:
        draw_video(button_frames[target_button_num], button_frames[target_button_num], video_set_frame=break_and_collect_pause_frames)
        break_and_collect_pause_frames = True
    if draw_debug_plate:
        draw_text(f"Slå på {target_button_text}", 30, WHITE, WIDTH // 2, HEIGHT // 2 + 50)
    
        # show player 1 a rectangle with the score
        if target_button is not None:
            pg.draw.rect(SCREEN, WHITE, (left_side[0], left_side[1], 100, 100))
            draw_text(f"{player1.get_score()}", 30, BLACK, left_side[0] + 50, left_side[1] + 50)
    
    if player1.get_score() >= 4 and not break_and_collect_outro_start:
        # WIN STATE
        # Draw outro frame
        print("WIN STATE")
        break_and_collect_outro_started = True
        break_and_collect_outro_start = True
        
        video.play()
    if break_and_collect_outro_start:
        print("WHAT THE FUCK")
        draw_video(break_and_collect_frame_outro[0], break_and_collect_frame_outro[1], video_set_frame=break_and_collect_outro_started)
        break_and_collect_outro_started = False
        
    
    if player1.get_score() < 4:
        if draw_debug_plate:
            pg.draw.rect(SCREEN, WHITE, plate_pos + plate_size)
    if player1.get_score() >= 4:
        
        
        if plate_step < plate_step_max:
            # add using timer and offset
            if plate_timer_offset is None:
                plate_timer_offset = pg.time.get_ticks()
            plate_timer = pg.time.get_ticks() - plate_timer_offset
            # lerp the plate step to the max step
            plate_step = int(plate_timer / 1000 * plate_step_max)
            # draw the plate
        
        if draw_debug_plate:
            draw_plate(plate_step)
        
        if plate_step >= plate_step_max:
            pass
            # Show text, "Press to collect product"
            #draw_text("Press to collect product", 30, WHITE, WIDTH // 2, HEIGHT // 2 + 50)
            # if player2 presses the key:
            # Make servo turn and collect the product
            
            
                
        
    
    
    
def update_state():
    global current_state, current_state_num, can_update_state, timer_offset, player1, player2, video_first_draw
    current_state_num = (current_state_num + 1) % len(all_states)
    current_state = all_states[current_state_num]
    can_update_state = False
    player1.set_score(0.0)
    player2.set_score(0.0)
    player1.ready = False
    player2.ready = False
    video_first_draw = True
    timer_offset = pg.time.get_ticks()
    



# State update logic
def handle_state(state, event):
    if state == STATE_INTRO:
        intro(event)
    elif state == STATE_MEASUREMENT:
        measurement(event)
    elif state == STATE_MIX:
        mix(event)
    elif state == STATE_TEMPERATURE:
        temperature(event)
    elif state == STATE_BREAK_AND_COLLECT:
        break_and_collect(event)

# Main loop
running = True
print(player2.get_score())
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

        elif event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE:
                running = False
            
            
            elif event.key == pg.K_RETURN and can_update_state == True: # Enter key to proceed to the next state
                # Cycle through states on space key press
                current_state_num = (current_state_num + 1) % len(all_states)
                current_state = all_states[current_state_num]
                can_update_state = False
                player1.set_score(0.0)
                player2.set_score(0.0)
                timer_offset = pg.time.get_ticks()
                print(f"Current State: {current_state}")
            
            if current_state == STATE_INTRO:
                if video:        
                    if event.key == pg.K_g: # Debug key
                        # Debugging: set frame
                        video.seek(217)
                        
                    if event.key == pg.K_SPACE:
                        if video.playing:
                            video.pause()
                        else:
                            video.play()
                    if video.get_current_frame_num >= intro_frame_stop[min(intro_num, len(intro_frame_stop)-1)]:
                        if event.key == player1.key:
                            player1.ready = True
                            print("Player 1 ready")
                        if event.key == player2.key:
                            player2.ready = True
                            print("Player 2 ready")
                        if player1.ready and player2.ready:
                            # If both players are ready, allow them to proceed
                            can_update_state = True
                            update_state()
                            print("Both players ready, proceeding to next state")
                    
            elif event.key == player1.key: # Player 1 key
                if current_state != STATE_MEASUREMENT or (current_state == STATE_MEASUREMENT and player1.get_score() < 10):
                    player1.update_score()
                
                print(f"{player1.name} Score: {player1.score}")
            elif event.key == player2.key: # Player 2 key
                
                    
                if current_state != STATE_TEMPERATURE:
                    if current_state != STATE_MEASUREMENT or (current_state == STATE_MEASUREMENT and player2.get_score() < 15):
                    
                        player2.update_score()
                elif current_state != STATE_BREAK_AND_COLLECT:
                    player2.add_score(2.5)
                #player2.update_score()
                print(f"{player2.name} Score: {player2.score}")
            
            elif event.key == pg.K_r: # Reset game
                reset_game()
                print("Game reset")
            elif event.key == pg.K_t: # Test key
                debug_state = not debug_state
            if STATE_BREAK_AND_COLLECT:
                if target_button is not None and player1.get_score() < 4:
                    if event.key == target_button:
                        player1.add_score(1.0)
                        target_button = None
                        print("Correct hit!")
                        # NEW
                        target_button_num = (target_button_num + 1) % len(button_list)
                        # SHOW CORRECT HIT
            
                
            
            

    handle_state(current_state, event)
    if debug_state:
        # debug print to display the current state
        draw_text(f"Current State: {current_state}", 20, WHITE, WIDTH // 2, HEIGHT - 60)
        # debug print to display the current player 1 and 2 scores
        draw_text(f"Player 1 Score: {player1.get_score()}", 20, WHITE, WIDTH // 2, HEIGHT - 40)
        draw_text(f"Player 2 Score: {player2.get_score()}", 20, WHITE, WIDTH // 2, HEIGHT - 20)
    
    pg.display.flip()
    CLOCK.tick(FPS)

pg.quit()
sys.exit()
