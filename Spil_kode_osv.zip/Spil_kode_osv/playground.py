import math

p1 = 0
p2 = 0

# ratio of p1 to p2 is 2:3


for p1 in range(11):
    for p2 in range(16):
        print(f"Arctan2({p1}, {p2}) = {math.atan2(p1, p2)}")
        if p1 / max(1, p2) == 2 / 3:
            print(f"p1: {p1}, p2: {p2}")
            