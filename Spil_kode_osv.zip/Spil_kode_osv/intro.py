
# --- MODIFIED INTRO FUNCTION ---
def intro(event, SCREEN, WIDTH, HEIGHT, CLOCK, draw_text_func, game_globals):
    """
    Handles the intro state, now with VideoPlayer.
    Args:
        event: Pygame event.
        SCREEN: Pygame display Surface.
        WIDTH, HEIGHT: Screen dimensions.
        CLOCK: Pygame clock for VideoPlayer.
        draw_text_func: Your function to draw text.
        game_globals (dict): A dictionary to access/modify global game state
                             like 'intro_video_player', 'intro_num', 'can_update_state', etc.
    """
    # Access and modify globals through the dictionary
    # This makes it easier to manage state if intro is called repeatedly or from different places.
    # If these are true Python globals, you'd use `global intro_video_player, intro_num, ...`

    if game_globals.get('intro_video_player') is None:
        VIDEO_PATH = "assets/your_intro_video.mp4"  # <--- IMPORTANT: CHANGE THIS TO YOUR VIDEO FILE!
                                                    # e.g., "intro.mp4" if it's in the same folder
                                                    # or "assets/intro_video.mp4" if in an 'assets' subfolder.
        print(f"Attempting to load video from: {VIDEO_PATH}")

        video_display_width = WIDTH * 2 // 3
        video_display_height = HEIGHT * 2 // 3
        
        game_globals['intro_video_player'] = VideoPlayer(
            video_path=VIDEO_PATH,
            game_clock=CLOCK, # Pass your main game clock
            loop=False,
            auto_play=True,
            frame_size=(video_display_width, video_display_height),
            position=(WIDTH // 2, HEIGHT // 2), # Centered
            centered=True
        )
        if not game_globals['intro_video_player'].loaded:
            print(f"Video player failed to load: {game_globals['intro_video_player'].error_message}")
            # No need to draw error here, player.draw() will handle it.

    # --- Video Update and Draw ---
    current_player = game_globals['intro_video_player']
    if current_player: # Check if player object exists
        if current_player.loaded:
            current_player.update() # Process next frame if playing
        # Always draw, even if not loaded, to show error message if any
        current_player.draw(SCREEN)

        # Optional: Display video status for debugging
        if current_player.loaded:
            status_text = f"Frame: {current_player.get_current_frame_num}/{current_player.get_total_frames} | {'Playing' if current_player.is_playing else 'Paused'}"
            draw_text_func(SCREEN, status_text, 20, (255,255,255), WIDTH // 2, HEIGHT - 70)
            draw_text_func(SCREEN, "SPACE: Play/Pause | J: Seek fr.100 | ENTER: Progress", 20, (255,255,255), WIDTH // 2, HEIGHT - 40)
        # If not loaded, the draw method itself will show the error_message at its position.

    # --- Event Handling for Video Control & Intro Progression ---
    if event.type == pg.KEYDOWN:
        if current_player and current_player.loaded: # Only allow video controls if loaded
            if event.key == pg.K_SPACE:
                if current_player.is_playing:
                    current_player.pause()
                else:
                    current_player.play()
            elif event.key == pg.K_j: # Example: Jump to frame 100
                current_player.seek(100)

        if event.key == pg.K_RETURN:
            if game_globals['intro_num'] == 0:
                # Allow progression if video is done, or failed to load, or is paused (user wants to skip)
                if not current_player or not current_player.loaded or current_player.ended or not current_player.is_playing:
                    game_globals['intro_num'] += 1
                    game_globals['timer_offset'] = pg.time.get_ticks()
                else:
                    print("Video still playing. Finish, pause, or let it end to proceed with Enter.")
            elif game_globals['intro_num'] == 1:
                if game_globals['intro_allow_next']:
                    game_globals['intro_num'] += 1
                    game_globals['intro_allow_next'] = False
                    game_globals['timer_offset'] = pg.time.get_ticks()
                else:
                    # This was original logic: pressing enter when not allowed resets timer
                    game_globals['timer_offset'] = pg.time.get_ticks()
            elif game_globals['intro_num'] == 2:
                if game_globals['intro_allow_next']:
                    game_globals['can_update_state'] = True # Signal to main loop to change game state
                    game_globals['intro_allow_next'] = False
                    if current_player: # Release video player when intro is truly done
                        current_player.release()
                        game_globals['intro_video_player'] = None
                else:
                    game_globals['intro_allow_next'] = True
                    # game_globals['timer_offset'] = pg.time.get_ticks() # Original logic, check if needed

    # --- Your existing intro_num specific logic ---
    # This logic might display text over/around the video.
    # Colors for text
    TEXT_COLOR = (255, 255, 255) # White
    BLACK_COLOR = (0,0,0) # Black (assuming defined)

    if game_globals['intro_num'] == 0:
        # Video is handled by the update/draw calls above.
        # You can add overlay text here if needed.
        if current_player and current_player.loaded:
            if current_player.ended:
                draw_text_func(SCREEN, "Video finished. Press Enter.", 30, TEXT_COLOR, WIDTH // 2, HEIGHT - 100)
        elif current_player and current_player.error_message:
             # Error is drawn by player, but you can add a general "Press Enter"
            draw_text_func(SCREEN, "Video error. Press Enter to continue.", 30, TEXT_COLOR, WIDTH // 2, HEIGHT - 100)
        elif not current_player: # Should not happen if init logic is correct
            draw_text_func(SCREEN, "Initializing intro...", 30, TEXT_COLOR, WIDTH // 2, HEIGHT // 2)

    elif game_globals['intro_num'] == 1:
        # SCREEN.fill(BLACK_COLOR) # Optionally clear screen if video shouldn't show
        timer_val = pg.time.get_ticks()
        if timer_val - game_globals['timer_offset'] < 10000: # 10 seconds
            draw_text_func(SCREEN, "Tag kittel og masker på", 30, TEXT_COLOR, WIDTH // 2, HEIGHT // 2)
        else:
            draw_text_func(SCREEN, "Har du taget det på?", 30, TEXT_COLOR, WIDTH // 2, HEIGHT // 2)
            game_globals['intro_allow_next'] = True

    elif game_globals['intro_num'] == 2:
        # SCREEN.fill(BLACK_COLOR) # Optionally clear screen
        draw_text_func(SCREEN, "Er du klar til at slippe din Breaking Bad drøm ud?", 30, TEXT_COLOR, WIDTH // 2, HEIGHT // 2)
        # intro_allow_next is set by K_RETURN in the event handling for intro_num 2
        # can_update_state is set when K_RETURN is pressed and intro_allow_next is True
