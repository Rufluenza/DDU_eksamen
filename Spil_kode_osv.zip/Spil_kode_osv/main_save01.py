import pygame as pg
import sys
import math
import time
from collections import deque
import random
import cv2
import numpy as np
from VideoPlayer import VideoPlayer


# Initialize Pygame
pg.init()

# Screen settings
WIDTH, HEIGHT = 1680, 1050 #1920, 1080 #800, 800
SCREEN = pg.display.set_mode((WIDTH, HEIGHT))
pg.display.set_caption("Breaking Bad Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (2, 39, 23) # 022717

# Clock
CLOCK = pg.time.Clock()
FPS = 60

# Game States
STATE_INTRO = "intro"
STATE_MEASUREMENT = "measurement"
STATE_MIX = "mix"
STATE_TEMPERATURE = "temperature"
STATE_BREAK_AND_COLLECT = "break_and_collect"

# Starting state

current_state_num = 0
start_current_state_num = current_state_num
all_states = [STATE_INTRO, STATE_MEASUREMENT, STATE_MIX, STATE_TEMPERATURE, STATE_BREAK_AND_COLLECT]
current_state = all_states[current_state_num]

debug_state = False

# Video settings
VIDEO_PATH = "assets/Video2.mp4"  # <--- IMPORTANT: Change this to your video file
cap = None
video_playing = True
current_frame_number = 0
total_frames = 0
video_loaded = False

# Constants
ROTATIONAL_AXIS_ID = [0, 1]     # Axis 0 = X, Axis 1 = Y
DEADZONE = 0.2
TIME_WINDOW = 5.0               # Track rotation in the last 5 seconds

# Globals
angle_history = deque()         # Stores (timestamp, angle)
rotation_count = 0
_rpm_current_value = 0
last_angle = None

blue_number_images = []
red_number_images = []
for i in range(16):
    blue_number_images.append(pg.image.load(f"assets/Blue{i}.png"))
    if i <= 10:
        red_number_images.append(pg.image.load(f"assets/Red{i}.png"))


# Initialize Joystick
pg.joystick.init()
joysticks = [pg.joystick.Joystick(i) for i in range(pg.joystick.get_count())]
game_joystick = None
joystick_available = False

if joysticks:
    game_joystick = joysticks[0]  # Use the first joystick found
    game_joystick.init()
    joystick_available = True
    print(f"Joystick '{game_joystick.get_name()}' initialized.")
    print(f"Number of axes: {game_joystick.get_numaxes()}")
    # You'll need to identify the correct axis for rotation on your Speedlink joystick.
    # Common axes for twist/rudder are 2, 3, or 4.
    # Check the console output when you run the game and move the rotational part of your joystick.
    print("Please test your joystick's axes to find the one for rotation.")
    print("The 'Axis X Value' will be shown in the MIXING phase.")
else:
    joystick_available = False
    print("No joystick detected.")



ROTATIONAL_AXIS_ID = [0, 1] # axis 0 = X, axis 1 = Y
_rpm_current_value = 0.0
MAX_RPM_FROM_JOYSTICK = 300 # Adjust this: max RPM when joystick axis is at full deflection


def draw_text(text, size, color, x, y):
    font = pg.font.SysFont("arial", size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(x, y))
    SCREEN.blit(text_surface, text_rect)

class Player:
    def __init__(self, name, key):
        self.name = name
        self.key = key
        self.score = 0.0 # action score for the game (ie. each press of the key)
        self.ready = False # ready to start the game
    
    def get_score(self):
        return self.score

    def update_score(self):
        self.score += 1.0
    
    def set_score(self, score):
        self.score = score
    
    def add_score(self, score):
        self.score += score
# Initialize players
player1 = Player("Player 1", pg.K_d)
player2 = Player("Player 2", pg.K_k)
can_update_state = False
timer = pg.time.get_ticks()
last_timer = 0
timer_offset = pg.time.get_ticks()
intro_num = 0
intro_allow_next = False
intro_video = None
intro_frame_stop = [217] # [90, 120, 165, 202]


def reset_game():
    global current_state_num, current_state, can_update_state, timer_offset, start_current_state_num
    current_state_num = start_current_state_num
    current_state = all_states[current_state_num]
    can_update_state = False
    player1.set_score(0.0)
    player2.set_score(0.0)
    timer_offset = pg.time.get_ticks()
    print(f"Game reset to state: {current_state}")



    


# State functions
def intro(event):
    global can_update_state, intro_allow_next, intro_num, timer_offset, current_state_num, intro_frame_stop
    global cap, video_playing, current_frame_number, total_frames, video_loaded, intro_video # Video globals
    
    # --- NEW VIDEO PLAYER ---
    
    if intro_video is None:
        intro_video = VideoPlayer(
            video_path=VIDEO_PATH,
            game_clock=CLOCK, # Pass your main game clock
            loop=False,
            auto_play=True,
            frame_size=(WIDTH, HEIGHT),
            position=(WIDTH // 2, HEIGHT // 2), # Centered
            centered=True
        )
        if not intro_video.loaded:
            print(f"Video player failed to load: {intro_video.error_message}")
            # No need to draw error here, player.draw() will handle it.
        
    if intro_video:
        if intro_video.loaded:
            
            if intro_video.get_current_frame_num <= intro_frame_stop[min(intro_num, len(intro_frame_stop)-1)]:
                print(f"Current frame: {intro_video.get_current_frame_num}/{intro_video.get_total_frames}")
                intro_video.update()
        intro_video.draw(SCREEN)
        if intro_video.loaded:
            status_text = f"Frame: {intro_video.get_current_frame_num}/{intro_video.get_total_frames} | {'Playing' if intro_video.is_playing else 'Paused'}"
            draw_text(status_text, 20, WHITE, WIDTH // 2, HEIGHT - 70)
            draw_text("SPACE: Play/Pause | J: Seek fr.100 | ENTER: Progress", 20, WHITE, WIDTH // 2, HEIGHT - 40)
        
    
    if event.type == pg.KEYDOWN:
        if event.key == pg.K_j:
            #intro_video.seek(100)
            print("Jumped to frame 100")
        if event.key == pg.K_SPACE:
            # Pause video
            if intro_video.playing:
                intro_video.pause()
            else:
                intro_video.play()
            print(f"Video {'paused' if not intro_video else 'playing'}")
        if event.key == pg.K_RETURN:
            print(f"Intro num: {intro_num}")
            if intro_video.get_current_frame_num >= intro_frame_stop[min(intro_num, len(intro_frame_stop)-1)]:
                if intro_num >= len(intro_frame_stop)-1:
                    can_update_state = True
                    update_state()
                    #current_state_num = (current_state_num + 1) % len(all_states)
                else:
                    intro_num += 1
                    
                    #video_playing = True
                    #intro_allow_next = False
                    # reset timer
                    #timer_offset = pg.time.get_ticks()
        
        
                
        
    # --- END NEW VIDEO PLAYER ---

    
    

def measurement(event):
    global can_update_state
    SCREEN.fill((30, 30, 30))
    draw_text("Measurement Phase", 30, WHITE, WIDTH // 2, HEIGHT // 8)

    # Draw center vertical line
    pg.draw.line(SCREEN, WHITE, (WIDTH // 2, 0), (WIDTH // 2, HEIGHT), 5)

    # Get player scores
    p1 = player1.get_score()
    p2 = player2.get_score()

    # Calculate ratio and angle
    if p2 == 0 and p1 == 0:
        angle_ratio = 0
    elif p2 == 0:
        angle_ratio = 1  # full tilt left
    else:
        ratio = p1 / p2
        ideal_ratio = 2 / 3
        diff = ratio - ideal_ratio

        # Normalize difference to range -1 to 1
        angle_ratio = max(-1.0, min(1.0, diff))

    # Convert to radians (max ±30 degrees → ±π/6 radians)
    angle_rad = angle_ratio * (math.pi / 6)

    # Scale line (like a seesaw)
    center = (WIDTH // 2, HEIGHT // 2)
    length = 200
    dx = math.cos(angle_rad) * length / 2
    dy = math.sin(angle_rad) * length / 2

    start = (center[0] - dx, center[1] + dy)
    end = (center[0] + dx, center[1] - dy)

    pg.draw.line(SCREEN, WHITE, start, end, 6)
    
    # Draw 2:3 on left side
    draw_text("2:3", 30, WHITE, WIDTH // 4, HEIGHT // 8)
    # Draw 3:2 on right side
    draw_text("3:2", 30, WHITE, WIDTH - WIDTH // 4, HEIGHT // 8)
    
    # show image of the score
    SCREEN.blit(red_number_images[int(p1)], (WIDTH // 4 - 50, HEIGHT // 2 - 50))
    SCREEN.blit(blue_number_images[int(p2)], (WIDTH - WIDTH // 4 - 50, HEIGHT // 2 - 50))

    # Optional: Show ratio and angle
    #ratio_display = round(p1 / p2, 2) if p2 != 0 else "∞"
    #draw_text(f"P1: {p1} | P2: {p2} | Ratio: {ratio_display}", 20, WHITE, WIDTH // 2, HEIGHT - 40)
    if p2 != 0 and p1 != 0:
        if round(p1 / p2, 2) == round(2 / 3, 2): # add a tolerance of 0.1
            #draw_text(f"Ratio: {round(p1 / p2, 2)}", 20, WHITE, WIDTH // 2, HEIGHT // 2)
            draw_text("Press Enter to proceed", 20, WHITE, WIDTH // 2, HEIGHT // 2 + 40)
            can_update_state = True
    
    

def get_angle(x, y):
    """Returns angle in degrees from joystick x, y input."""
    return math.degrees(math.atan2(-y, x)) % 360  # atan2 uses -y to make up = 0°

rpm_target_timer_offset = 0
def mix(event):
    global _rpm_current_value, last_angle, rotation_count, rpm_target_timer_offset, can_update_state


    SCREEN.fill((50, 50, 80))
    draw_text("Mixing Phase", 30, WHITE, WIDTH // 2, HEIGHT // 8)

    if joystick_available and game_joystick:
        x = game_joystick.get_axis(ROTATIONAL_AXIS_ID[0])
        y = game_joystick.get_axis(ROTATIONAL_AXIS_ID[1])

        # Deadzone
        if abs(x) < DEADZONE:
            x = 0.0
        if abs(y) < DEADZONE:
            y = 0.0

        # Draw axis info
        draw_text(f"Axis ({ROTATIONAL_AXIS_ID[0]}, {ROTATIONAL_AXIS_ID[1]}): ({x:.2f}, {y:.2f})", 
                  20, WHITE, WIDTH // 2, HEIGHT // 2 + 60)

        if x != 0.0 or y != 0.0:
            current_time = time.time()
            current_angle = get_angle(x, y)

            if last_angle is not None:
                delta = (current_angle - last_angle + 540) % 360 - 180  # Normalize to [-180, 180]
                
                # Track rotation
                angle_history.append((current_time, current_angle))

            last_angle = current_angle

        # Clean up history older than TIME_WINDOW
        now = time.time()
        while angle_history and now - angle_history[0][0] > TIME_WINDOW:
            angle_history.popleft()

        # Count full rotations
        total_angle_change = 0.0
        prev_angle = None
        for t, a in angle_history:
            if prev_angle is not None:
                delta = (a - prev_angle + 540) % 360 - 180
                total_angle_change += delta
            prev_angle = a

        # Compute number of full rotations
        rotations = abs(total_angle_change / 360.0)
        _rpm_current_value = (rotations / TIME_WINDOW) * 60.0

        draw_text(f"RPM: {int(_rpm_current_value)}", 30, WHITE, WIDTH // 4, HEIGHT // 2)
        rpm_target = 50

        if _rpm_current_value < rpm_target:
            # Reset the timer if we drop below target
            rpm_target_timer_offset = None
        else:
            if rpm_target_timer_offset is None:
                rpm_target_timer_offset = pg.time.get_ticks()  # Start the countdown

            if pg.time.get_ticks() - rpm_target_timer_offset > 5000:
                can_update_state = True
                draw_text("Mixing complete! Press Enter.", 20, WHITE, WIDTH // 2, HEIGHT - 50)
                print("Mixing complete! Press Enter to proceed.")

    else:
        draw_text("Joystick not detected!", 20, WHITE, WIDTH // 2, HEIGHT // 2 + 60)
        draw_text("RPM: N/A", 30, WHITE, WIDTH // 4, HEIGHT // 2)
        # can_update_state = True # Or False, depending on desired behavior without joystick
    
    # Draw circle on left side of screen
def draw_pie_slice(surface, center, radius, start_deg, end_deg, color, points=20):
    start_rad = math.radians(start_deg)
    end_rad = math.radians(end_deg)

    angle_step = (end_rad - start_rad) / points
    point_list = [center]

    for i in range(points + 1):
        angle = start_rad + i * angle_step
        x = center[0] + math.cos(angle) * radius
        y = center[1] + math.sin(angle) * radius
        point_list.append((x, y))

    pg.draw.polygon(surface, color, point_list)
    
def temperature(event):
    global can_update_state  # timer_offset is a global, read but not modified here.
                             # timer and last_timer globals are not used in this corrected version.
    SCREEN.fill((80, 30, 30))
    draw_text("Temperature Control Phase", 30, WHITE, WIDTH // 2, HEIGHT // 8) # Adjusted y for consistency

    center = (WIDTH // 4, HEIGHT // 2)
    radius = WIDTH // 8
    temp_range_degrees = 60  # The visual extent of the green zone in degrees
    green_zone_start_angle = 180  # Starting angle of the green zone
    green_zone_end_angle = green_zone_start_angle + temp_range_degrees

    # Draw the visual elements for temperature control
    pg.draw.circle(SCREEN, WHITE, center, radius)
    draw_pie_slice(SCREEN, center, radius, green_zone_start_angle, green_zone_end_angle, GREEN)

    # --- Corrected Timer and Score Logic ---

    # 1. Address: "it starts with a value of around 500"
    #    The previous logic for 'timer' calculation and its use in player2.add_score was causing this.
    #    Those lines have been removed.

    # Implement a steady temperature decay (player2.score decreases over time)
    COOLING_RATE_PER_FRAME = 0.15  # Adjust this value for game balance (how fast temperature drops)

    # 2. Address: "i need it to not subtract the score when the value is under 0"
    if player2.get_score() > 0:
        new_score = player2.get_score() - COOLING_RATE_PER_FRAME
        player2.set_score(max(0, new_score))  # Ensure score doesn't drop below 0
    # If player2.get_score() is already 0 or less, it won't be further reduced by automatic cooling.
    # Player 2 pressing their key (pg.K_k) will increase the score via player2.update_score() in the event loop.

    # --- Needle and Win Condition Logic ---
    needle_length = 100
    # player2.score is treated as the current "temperature value".
    # The needle's angle is derived from this score. Assuming score * 10 = degrees for the needle.
    current_needle_angle = player2.get_score() * 10 - 90

    # Draw the temperature needle
    pg.draw.line(SCREEN, BLACK,
                (center[0], center[1]),  # Starting point of the needle (center of the circle)
                (center[0] + math.cos(math.radians(current_needle_angle)) * needle_length,
                 center[1] + math.sin(math.radians(current_needle_angle)) * needle_length),
                5)  # Thickness of the needle

    # Determine if the current temperature (represented by the needle's angle) is in the target green zone
    normalized_needle_angle = current_needle_angle % 360  # Normalize angle to 0-360 range

    if green_zone_start_angle <= normalized_needle_angle <= green_zone_end_angle:
        can_update_state = True  # Player can proceed to the next state
    else:
        can_update_state = False

    # Optional: For debugging, you can print score and angle
    # print(f"P2 Score: {player2.get_score():.2f}, Needle Angle: {current_needle_angle:.2f}, In Zone: {can_update_state}")
    
plate_step = 0
plate_step_max = 100
plate_timer_offset = None
plate_timer = 0
def draw_plate(step):
    # Draw the plate
    plate_size = (600, 400)
    plate_pos = (WIDTH // 4 - plate_size[0] // 2 + (step/100*WIDTH//2), HEIGHT // 2 - plate_size[1] // 2)
    pg.draw.rect(SCREEN, WHITE, plate_pos + plate_size)

    # Draw the step number
    draw_text(f"Step {step}", 30, BLACK, plate_pos[0] + plate_size[0] // 2, plate_pos[1] + plate_size[1] // 2)

button_list = [pg.K_a, pg.K_s, pg.K_q, pg.K_w]
button_list_text = ["A", "S", "Q", "W"]
target_button = None
target_button_num = 0

def break_and_collect(event):
    global can_update_state, plate_step, plate_step_max, plate_timer_offset, plate_timer, target_button, button_list, button_list_text, target_button_num
    SCREEN.fill((20, 60, 20))
    draw_text("Break & Collect Product Phase", 30, WHITE, WIDTH // 2, HEIGHT // 2)
    # show the player 1 a rectangle with the score
    left_side = (WIDTH // 2 - 50, HEIGHT // 2 - 50)
    right_side = (WIDTH // 2 + 50, HEIGHT // 2 - 50)
    plate_size = (600, 400)
    plate_pos = (WIDTH // 4 - plate_size[0] // 2, HEIGHT // 2 - plate_size[1] // 2)
    
    # show player 2 a random button from button list
    if target_button is None:
        #target_button = random.choice(button_list)
        target_button = button_list[target_button_num]
    target_button_text = button_list_text[button_list.index(target_button)]
    
    draw_text(f"Slå på {target_button_text}", 30, WHITE, WIDTH // 2, HEIGHT // 2 + 50)
    # show player 1 a rectangle with the score
    if target_button is not None:
        pg.draw.rect(SCREEN, WHITE, (left_side[0], left_side[1], 100, 100))
        draw_text(f"{player1.get_score()}", 30, BLACK, left_side[0] + 50, left_side[1] + 50)
    
    
    
    if player1.get_score() < 4:
        pg.draw.rect(SCREEN, WHITE, plate_pos + plate_size)
    if player1.get_score() >= 4:
        
        if plate_step < plate_step_max:
            # add using timer and offset
            if plate_timer_offset is None:
                plate_timer_offset = pg.time.get_ticks()
            plate_timer = pg.time.get_ticks() - plate_timer_offset
            # lerp the plate step to the max step
            plate_step = int(plate_timer / 1000 * plate_step_max)
            # draw the plate
        draw_plate(plate_step)
        
        if plate_step >= plate_step_max:
            # Show text, "Press to collect product"
            draw_text("Press to collect product", 30, WHITE, WIDTH // 2, HEIGHT // 2 + 50)
            # if player2 presses the key:
            # Make servo turn and collect the product
            
                
        
    
    
    
def update_state():
    global current_state, current_state_num, can_update_state
    current_state_num = (current_state_num + 1) % len(all_states)
    current_state = all_states[current_state_num]
    can_update_state = False
    player1.set_score(0.0)
    player2.set_score(0.0)
    player1.ready = False
    player2.ready = False
    timer_offset = pg.time.get_ticks()
    



# State update logic
def handle_state(state, event):
    if state == STATE_INTRO:
        intro(event)
    elif state == STATE_MEASUREMENT:
        measurement(event)
    elif state == STATE_MIX:
        mix(event)
    elif state == STATE_TEMPERATURE:
        temperature(event)
    elif state == STATE_BREAK_AND_COLLECT:
        break_and_collect(event)

# Main loop
running = True
print(player2.get_score())
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

        elif event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE:
                running = False
            
            
            elif event.key == pg.K_RETURN and can_update_state == True: # Enter key to proceed to the next state
                # Cycle through states on space key press
                current_state_num = (current_state_num + 1) % len(all_states)
                current_state = all_states[current_state_num]
                can_update_state = False
                player1.set_score(0.0)
                player2.set_score(0.0)
                timer_offset = pg.time.get_ticks()
                print(f"Current State: {current_state}")
            
            if current_state == STATE_INTRO:
                if intro_video:        
                    if event.key == pg.K_g: # Debug key
                        # Debugging: set frame
                        intro_video.seek(217)
                        
                    if event.key == pg.K_SPACE:
                        if intro_video.playing:
                            intro_video.pause()
                        else:
                            intro_video.play()
                    if intro_video.get_current_frame_num >= intro_frame_stop[min(intro_num, len(intro_frame_stop)-1)]:
                        if event.key == player1.key:
                            player1.ready = True
                            print("Player 1 ready")
                        if event.key == player2.key:
                            player2.ready = True
                            print("Player 2 ready")
                        if player1.ready and player2.ready:
                            # If both players are ready, allow them to proceed
                            can_update_state = True
                            update_state()
                            print("Both players ready, proceeding to next state")
                    
            elif event.key == player1.key: # Player 1 key
                if current_state != STATE_MEASUREMENT or (current_state == STATE_MEASUREMENT and player1.get_score() < 10):
                    player1.update_score()
                
                print(f"{player1.name} Score: {player1.score}")
            elif event.key == player2.key: # Player 2 key
                
                    
                if current_state != STATE_TEMPERATURE:
                    if current_state != STATE_MEASUREMENT or (current_state == STATE_MEASUREMENT and player2.get_score() < 15):
                    
                        player2.update_score()
                elif current_state != STATE_BREAK_AND_COLLECT:
                    player2.add_score(2.5)
                #player2.update_score()
                print(f"{player2.name} Score: {player2.score}")
            
            elif event.key == pg.K_r: # Reset game
                reset_game()
                print("Game reset")
            elif event.key == pg.K_t: # Test key
                debug_state = not debug_state
            if STATE_BREAK_AND_COLLECT:
                if target_button is not None and player1.get_score() < 4:
                    if event.key == target_button:
                        player1.add_score(1.0)
                        target_button = None
                        print("Correct hit!")
                        # NEW
                        target_button_num = (target_button_num + 1) % len(button_list)
                        # SHOW CORRECT HIT
            
                
            
            

    handle_state(current_state, event)
    if debug_state:
        # debug print to display the current state
        draw_text(f"Current State: {current_state}", 20, WHITE, WIDTH // 2, HEIGHT - 60)
        # debug print to display the current player 1 and 2 scores
        draw_text(f"Player 1 Score: {player1.get_score()}", 20, WHITE, WIDTH // 2, HEIGHT - 40)
        draw_text(f"Player 2 Score: {player2.get_score()}", 20, WHITE, WIDTH // 2, HEIGHT - 20)
    
    pg.display.flip()
    CLOCK.tick(FPS)

pg.quit()
sys.exit()
