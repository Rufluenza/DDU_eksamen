import pygame as pg
import sys
import math
import time
from collections import deque
import random
import cv2  # For video processing
import numpy as np # For image array manipulation



class VideoPlayer:
    """
    A class to handle video playback in Pygame using OpenCV.
    """
    def __init__(self, video_path, game_clock, loop=False, auto_play=True,
                 frame_size=None, position=(0,0), centered=True):
        """
        Initializes the VideoPlayer.
        Args:
            video_path (str): Path to the video file.
            game_clock (pygame.time.Clock): The main Pygame clock for FPS-independent playback.
            loop (bool): Whether the video should loop.
            auto_play (bool): Whether the video should start playing automatically after loading.
            frame_size (tuple, optional): (width, height) to scale frames. Defaults to None (original size).
            position (tuple): (x, y) position for drawing the video.
            centered (bool): If True, position is the center for blitting; otherwise, it's top-left.
        """
        self.video_path = video_path
        self.game_clock = game_clock
        self.loop = loop
        self.frame_size = frame_size
        self.position = position
        self.centered = centered

        self.cap = None
        self.playing = False
        self.loaded = False
        self.current_frame_number = 0
        self.total_frames = 0
        self.video_fps = 0
        self.frame_duration_ms = 0 # Milliseconds per frame of the video
        self.time_since_last_frame_update = 0 # Accumulated game time

        self.current_surface = None
        self.error_message = None

        self._load()
        if self.loaded and auto_play:
            self.play()

    def _load(self):
        """Loads the video file."""
        try:
            self.cap = cv2.VideoCapture(self.video_path)
            if not self.cap.isOpened():
                self.error_message = f"Error: Could not open video '{self.video_path}'"
                print(self.error_message)
                self.loaded = False
                return

            self.total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
            self.video_fps = self.cap.get(cv2.CAP_PROP_FPS)

            if self.total_frames <= 0 or self.video_fps <= 0:
                self.error_message = f"Error: Video has no frames or invalid FPS '{self.video_path}'"
                print(self.error_message)
                self.cap.release()
                self.loaded = False
                return

            self.frame_duration_ms = 1000 / self.video_fps
            self.loaded = True
            self.current_frame_number = 0
            # Read the first frame immediately to have something to display if not auto-playing
            self._read_and_process_frame()
            print(f"Video loaded: '{self.video_path}', Frames: {self.total_frames}, FPS: {self.video_fps:.2f}")

        except Exception as e:
            self.error_message = f"Exception loading video: {e}"
            print(self.error_message)
            if self.cap is not None:
                self.cap.release()
            self.loaded = False

    def play(self):
        """Starts or resumes video playback."""
        if self.loaded and not self.playing:
            # If at the end of a non-looping video, restart from the beginning
            if not self.loop and self.current_frame_number >= self.total_frames - 1:
                self.seek(0)
            self.playing = True
            self.time_since_last_frame_update = 0 # Reset accumulator
            print("Video playing.")

    def pause(self):
        """Pauses video playback."""
        if self.playing:
            self.playing = False
            print("Video paused.")

    def stop(self):
        """Stops video playback and resets to the first frame."""
        self.pause()
        self.seek(0)
        print("Video stopped and reset.")

    def seek(self, frame_number):
        """
        Seeks to a specific frame number.
        Args:
            frame_number (int): The frame number to seek to (0-indexed).
        """
        if not self.loaded:
            return
        target_frame = max(0, min(int(frame_number), self.total_frames - 1))
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
        # Read the frame to update current_surface and current_frame_number accurately
        self._read_and_process_frame()
        #print(f"Video seeked. Current frame after seek: {self.current_frame_number}")


    def _read_and_process_frame(self):
        """Reads the next frame from the video and converts it to a Pygame surface."""
        if not self.loaded or not self.cap.isOpened():
            return False

        ret, frame = self.cap.read()
        if ret:
            self.current_frame_number = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES)) - 1
            if self.current_frame_number < 0: self.current_frame_number = 0 # Safety

            # OpenCV reads frames as BGR, Pygame needs RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            self.current_surface = pg.surfarray.make_surface(frame_rgb.swapaxes(0, 1))

            if self.frame_size: # Scale if a specific frame size is requested
                self.current_surface = pg.transform.scale(self.current_surface, self.frame_size)
            return True
        else:
            # End of video or error reading frame
            if self.loop:
                print("Video looping.")
                self.seek(0) # This will also call _read_and_process_frame
                # Ensure playing state is maintained if it was playing
                # self.playing = True (seek might pause it if it internally calls pause)
                # The seek method should ideally not change the playing state directly.
                # Let's assume if loop is true, we want it to continue playing.
                if not self.playing: # If seek somehow paused it, resume
                    self.playing = True

            else:
                self.playing = False # Stop playing if not looping and end is reached
                self.current_frame_number = self.total_frames - 1 # Ensure it stays at the last frame
            return False

    def update(self):
        """
        Updates the video frame based on elapsed time.
        Call this once per game loop.
        """
        if not self.loaded or not self.playing:
            return

        # Accumulate elapsed game time
        self.time_since_last_frame_update += self.game_clock.get_time()

        # Advance video frames if enough time has passed
        frames_advanced_this_update = 0
        while self.playing and self.time_since_last_frame_update >= self.frame_duration_ms:
            if not self._read_and_process_frame(): # Reads next frame, handles looping/end
                # If read failed (e.g., end of non-looping video), _read_and_process_frame sets self.playing = False
                break
            self.time_since_last_frame_update -= self.frame_duration_ms
            frames_advanced_this_update +=1
            # Safety break for very low video FPS / high game FPS to avoid freezing
            if frames_advanced_this_update > self.video_fps * 2 and self.video_fps > 0 :
                 print("Warning: Advancing too many video frames in one game update. Check FPS sync.")
                 break


    def draw(self, target_surface):
        """
        Draws the current video frame onto the target surface.
        Args:
            target_surface (pygame.Surface): The surface to draw the video on.
        """
        if not self.loaded:
            if self.error_message: # Display error on screen if video failed to load
                # Simple error text rendering
                font = pg.font.SysFont("arial", 24)
                text_surf = font.render(self.error_message, True, (255, 0, 0)) # Red color for error
                rect = text_surf.get_rect()
                if self.centered:
                    rect.center = self.position
                else:
                    rect.topleft = self.position
                target_surface.blit(text_surf, rect)
            return

        if self.current_surface:
            if self.centered:
                rect = self.current_surface.get_rect(center=self.position)
                target_surface.blit(self.current_surface, rect)
            else:
                target_surface.blit(self.current_surface, self.position)

    def release(self):
        """Releases video capture resources."""
        if self.cap is not None:
            self.cap.release()
        self.loaded = False
        self.playing = False
        self.current_surface = None
        print("Video resources released.")

    @property
    def is_playing(self):
        return self.playing

    @property
    def get_current_frame_num(self): # Renamed for clarity
        return self.current_frame_number

    @property
    def get_total_frames(self):
        return self.total_frames

    @property
    def ended(self):
        """Checks if the video has ended (for non-looping videos)."""
        return self.loaded and not self.loop and self.current_frame_number >= self.total_frames - 1


# Global variable for the video player instance for the intro
# This should be defined in the global scope of your main.py
intro_video_player = None

