from m5stack import *
from m5ui import *
from uiflow import *
import machine
import time

# Setup
servo_pin = machine.Pin(26)
servo_pwm = machine.PWM(servo_pin, freq=10)
dual_button_0 = unit.get(unit.DUAL_BUTTON, unit.PORTA)

setScreenColor(0x00ff00)
def set_servo_angle(angle):
    min_us = 500
    max_us = 2500
    us = min_us + (angle / 180.0) * (max_us - min_us)
    duty = int((us / 20000) * 100)  # Convert microseconds to duty cycle %
    if angle == 0:
      duty = 0
    servo_pwm.duty(duty)


# State flags
turned = False
all_run = True
stop_angle = 2
stop_change = False



def move_func():
    global turned, stop_angle, stop_change
    #turned = not turned
    
    
    if not turned:
        setScreenColor(0xff0000)  # Red background to show action
        # Slowly turn from 0 to 180 degrees
        for angle in range(stop_angle):
            set_servo_angle(-1)
            time.sleep(0.02)
            angle += 1
            if angle == stop_angle:
              turned = True
              break
            
        turned = True
    else:
        turned = False
        set_servo_angle(0)
        setScreenColor(0x00ff00)
        
        # Already turned, do nothing or show feedback
        pass

def buttonA_wasPressed():
    global turned, stop_angle, stop_change
    move_func()

def btnRed0_wasPressed():
    global turned, stop_angle, stop_change
    move_func()
dual_button_0.btnRed.wasPressed(btnRed0_wasPressed)
def btnBlue0_wasPressed():
    global turned, stop_angle, stop_change
    move_func()
dual_button_0.btnBlue.wasPressed(btnBlue0_wasPressed)

def buttonB_wasPressed():
    global all_run
    all_run = False  # Stop the main loop

# Register button callbacks
btnA.wasPressed(buttonA_wasPressed)
btnB.wasPressed(buttonB_wasPressed)

# Idle loop

#while all_run:
#    wait_ms(100)
